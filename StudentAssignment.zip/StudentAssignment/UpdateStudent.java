package com.demo;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateStudent")
public class UpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdateStudent() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String bookId = request.getParameter("rollno");
		int rno = Integer.parseInt(bookId);
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String city = request.getParameter("city");
		String dateOfJoining = request.getParameter("dateOfJoining");
		String technologies = request.getParameter("technologies");
		String password = request.getParameter("password");
		System.out.println(bookId);
		System.out.println(name);
		System.out.println(id);
		System.out.println(city);
		System.out.println(dateOfJoining);
		System.out.println(technologies);
		System.out.println(password);

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
			PreparedStatement ps = con.prepareStatement(
					"update studentreg set name=?, id=?,city=? ,dateOfJoining=?, technologies=?,password=? where roll=?");

			ps.setString(1, name);
			ps.setString(2, id);
			ps.setString(3, city);
			ps.setString(4, dateOfJoining);
			ps.setString(5, technologies);
			ps.setString(6, password);
			ps.setInt(7, rno);

			ps.executeUpdate();
			System.out.println("Record Added Successsfully......");

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("ViewAllStudents.jsp");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
